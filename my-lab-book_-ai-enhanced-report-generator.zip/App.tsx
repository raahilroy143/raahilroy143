
import React, { useState, useEffect, useCallback } from 'react';
import type { PatientData, TestResult, Report, TestDefinition } from './types';
import { Page } from './types';
import PatientInfoPage from './components/PatientInfoPage';
import TestSelectionPage from './components/TestSelectionPage';
import TestDetailsPage from './components/TestDetailsPage';
import ReportPreviewPage from './components/ReportPreviewPage';
import Header from './components/Header';
import Toast from './components/Toast';
import { loadReports as loadReportsFromStorage } from './services/reportService';

const App: React.FC = () => {
    const [currentPage, setCurrentPage] = useState<Page>(Page.PatientInfo);
    const [patientData, setPatientData] = useState<PatientData | null>(null);
    const [selectedTests, setSelectedTests] = useState<TestResult[]>([]);
    const [currentTest, setCurrentTest] = useState<TestDefinition | null>(null);
    const [reports, setReports] = useState<Report[]>([]);
    const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

    const showToast = (message: string, type: 'success' | 'error' | 'info' = 'info') => {
        setToast({ message, type });
        setTimeout(() => setToast(null), 3000);
    };

    const loadReports = useCallback(() => {
        const savedReports = loadReportsFromStorage();
        setReports(savedReports);
    }, []);

    useEffect(() => {
        loadReports();
    }, [loadReports]);
    
    const handlePatientDataSave = (data: PatientData) => {
        setPatientData(data);
        setCurrentPage(Page.TestSelection);
        showToast('Patient information saved!', 'success');
    };

    const handleTestSelect = (test: TestDefinition) => {
        setCurrentTest(test);
        setCurrentPage(Page.TestDetails);
    };

    const handleTestSave = (testResult: TestResult) => {
        setSelectedTests(prevTests => {
            const existingIndex = prevTests.findIndex(t => t.name === testResult.name);
            if (existingIndex > -1) {
                const updatedTests = [...prevTests];
                updatedTests[existingIndex] = testResult;
                showToast('Test details updated!', 'success');
                return updatedTests;
            } else {
                showToast('Test added successfully!', 'success');
                return [...prevTests, testResult];
            }
        });
        setCurrentPage(Page.TestDetails); // Stay on the page to allow adding more
    };
    
    const handleDeleteTest = (testNameToDelete: string) => {
        setSelectedTests(prev => prev.filter(t => t.name !== testNameToDelete));
        showToast('Test removed.', 'info');
    };

    const handleLoadReport = (report: Report) => {
        setPatientData(report.patientData);
        setSelectedTests(report.tests);
        showToast(`Report for ${report.patientData.name} loaded.`, 'success');
        setCurrentPage(Page.PatientInfo); // Start at patient page with loaded data
    };
    
    const handleNewReport = () => {
        setPatientData(null);
        setSelectedTests([]);
        setCurrentTest(null);
        setCurrentPage(Page.PatientInfo);
        showToast('New report started.', 'info');
    };

    const renderPage = () => {
        switch (currentPage) {
            case Page.PatientInfo:
                return (
                    <PatientInfoPage
                        onSave={handlePatientDataSave}
                        setCurrentPage={setCurrentPage}
                        reports={reports}
                        loadReport={handleLoadReport}
                        deleteReportCallback={loadReports}
                        showToast={showToast}
                        initialData={patientData}
                        startNewReport={handleNewReport}
                    />
                );
            case Page.TestSelection:
                return (
                    <TestSelectionPage
                        onTestSelect={handleTestSelect}
                        setCurrentPage={setCurrentPage}
                        patientData={patientData}
                    />
                );
            case Page.TestDetails:
                return (
                    <TestDetailsPage
                        testDefinition={currentTest}
                        patientData={patientData}
                        onSaveTest={handleTestSave}
                        selectedTests={selectedTests}
                        onDeleteTest={handleDeleteTest}
                        onEditTest={handleTestSelect}
                        setCurrentPage={setCurrentPage}
                    />
                );
            case Page.ReportPreview:
                if (!patientData) {
                    setCurrentPage(Page.PatientInfo);
                    showToast('Patient data not found. Please start a new report.', 'error');
                    return null;
                }
                return (
                    <ReportPreviewPage
                        patientData={patientData}
                        selectedTests={selectedTests}
                        setCurrentPage={setCurrentPage}
                        showToast={showToast}
                        refreshReports={loadReports}
                    />
                );
            default:
                return <PatientInfoPage onSave={handlePatientDataSave} setCurrentPage={setCurrentPage} reports={reports} loadReport={handleLoadReport} deleteReportCallback={loadReports} showToast={showToast} initialData={patientData} startNewReport={handleNewReport}/>;
        }
    };

    return (
        <div className="min-h-screen p-5 flex flex-col items-center">
            <div className="container w-full max-w-screen-xl mx-auto">
                <Header />
                <main className={currentPage === Page.ReportPreview ? 'print-this' : ''}>
                    {renderPage()}
                </main>
                {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
            </div>
        </div>
    );
};

export default App;
