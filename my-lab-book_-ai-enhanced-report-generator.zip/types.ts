
export enum Page {
    PatientInfo,
    TestSelection,
    TestDetails,
    ReportPreview,
}

export interface PatientData {
    name: string;
    age: string;
    id: string;
    date: string;
    caseNumber: string;
    physician: string;
}

export interface TestResult {
    name: string;
    value: string;
    unit: string;
    range: string;
    status: 'normal' | 'high' | 'low' | 'mild' | 'abnormal';
    interpretation: string;
    sampleType: string;
}

export interface TestDefinition {
    name: string;
    description: string;
    category: string;
    sampleType: string;
    unit: string;
    range: string | { male: string; female: string; child: string; };
    defaultRange?: string;
    defaultValue?: string;
    interpretation: {
        high?: string;
        normal?: string;
        low?: string;
        abnormal?: string;
    };
    subTests?: TestDefinition[];
}

export interface TestCategory {
    id: string;
    name: string;
    tests: TestDefinition[];
}

export interface Report {
    id: string;
    patientData: PatientData;
    tests: TestResult[];
    createdAt: string;
}
