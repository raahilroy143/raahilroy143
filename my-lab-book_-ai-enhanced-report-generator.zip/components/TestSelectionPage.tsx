
import React, { useState, useMemo } from 'react';
import type { PatientData, TestDefinition, TestCategory } from '../types';
import { Page } from '../types';
import { TEST_CATEGORIES } from '../constants';
import PageNavigation from './PageNavigation';
import { ChevronDownIcon, SearchIcon } from './Icons';

interface AccordionProps {
    test: TestDefinition;
    onTestSelect: (test: TestDefinition) => void;
}

const Accordion: React.FC<AccordionProps> = ({ test, onTestSelect }) => {
    const [isOpen, setIsOpen] = useState(false);

    return (
        <div className="mb-3">
            <button
                onClick={() => setIsOpen(!isOpen)}
                className="w-full flex justify-between items-center bg-blue-100 text-blue-800 font-semibold p-4 rounded-lg hover:bg-blue-200 transition-colors"
            >
                <span>{test.name}</span>
                <ChevronDownIcon className={`transform transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
            </button>
            <div
                className={`overflow-hidden transition-all duration-500 ease-in-out ${isOpen ? 'max-h-screen' : 'max-h-0'}`}
            >
                <div className="p-4 bg-white border border-t-0 border-blue-100 rounded-b-lg">
                    <p className="mb-4 text-gray-600">{test.description}</p>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-2">
                        {test.subTests?.map(sub => (
                             <div key={sub.name}
                                onClick={() => onTestSelect(sub)}
                                className="p-3 bg-blue-50 border border-blue-200 rounded-md cursor-pointer hover:bg-blue-200 hover:shadow-md transition-all duration-200 transform hover:-translate-y-0.5"
                            >
                                <div className="font-semibold text-blue-900">{sub.name}</div>
                            </div>
                        ))}
                    </div>
                </div>
            </div>
        </div>
    );
};

interface TestSelectionPageProps {
    onTestSelect: (test: TestDefinition) => void;
    setCurrentPage: (page: Page) => void;
    patientData: PatientData | null;
}

const TestSelectionPage: React.FC<TestSelectionPageProps> = ({ onTestSelect, setCurrentPage }) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [activeFilter, setActiveFilter] = useState('all');

    const filteredCategories = useMemo(() => {
        if (!searchTerm && activeFilter === 'all') {
            return TEST_CATEGORIES;
        }

        const lowercasedFilter = searchTerm.toLowerCase();

        return TEST_CATEGORIES
            .map(category => {
                if (activeFilter !== 'all' && category.id !== activeFilter) {
                    return null;
                }

                const filteredTests = category.tests.filter(test => {
                    const hasMatchingSubtest = test.subTests?.some(sub => sub.name.toLowerCase().includes(lowercasedFilter));
                    return test.name.toLowerCase().includes(lowercasedFilter) ||
                           test.description.toLowerCase().includes(lowercasedFilter) ||
                           hasMatchingSubtest;
                });

                if (filteredTests.length > 0) {
                    return { ...category, tests: filteredTests };
                }
                return null;
            })
            .filter((c): c is TestCategory => c !== null);
    }, [searchTerm, activeFilter]);

    return (
        <div className="page active">
            <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-blue-100">
                <h2 className="text-center text-blue-700 mb-6 text-2xl font-bold">Laboratory Tests Selection</h2>
                
                <div className="mb-6">
                    <div className="relative">
                        <input
                            type="text"
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            placeholder="Search for tests..."
                            className="w-full p-3 pl-10 border-2 rounded-full bg-gray-50 border-blue-100 focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-300 transition-colors"
                        />
                        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400">
                            <SearchIcon />
                        </div>
                    </div>
                    <div className="flex flex-wrap gap-2 mt-4">
                        <button onClick={() => setActiveFilter('all')} className={`px-4 py-1 rounded-full text-sm font-semibold transition-colors ${activeFilter === 'all' ? 'bg-blue-500 text-white' : 'bg-blue-100 text-blue-700 hover:bg-blue-200'}`}>All</button>
                        {TEST_CATEGORIES.map(cat => (
                             <button key={cat.id} onClick={() => setActiveFilter(cat.id)} className={`px-4 py-1 rounded-full text-sm font-semibold transition-colors ${activeFilter === cat.id ? 'bg-blue-500 text-white' : 'bg-blue-100 text-blue-700 hover:bg-blue-200'}`}>{cat.name}</button>
                        ))}
                    </div>
                </div>

                <div>
                    {filteredCategories.map(category => (
                        <div key={category.id} className="mb-8">
                            <h3 className="text-xl font-bold text-blue-700 mb-4 pb-2 border-b-2 border-blue-100">{category.name}</h3>
                            {category.tests.map(test =>
                                test.subTests ? (
                                    <Accordion key={test.name} test={test} onTestSelect={onTestSelect} />
                                ) : (
                                    <div
                                        key={test.name}
                                        onClick={() => onTestSelect(test)}
                                        className="p-4 mb-2 bg-blue-50 border border-blue-200 rounded-lg cursor-pointer hover:bg-blue-200 hover:shadow-lg transition-all duration-200 transform hover:-translate-y-0.5"
                                    >
                                        <div className="font-semibold text-blue-900">{test.name}</div>
                                        <div className="text-sm text-gray-600">{test.description}</div>
                                    </div>
                                )
                            )}
                        </div>
                    ))}
                     {filteredCategories.length === 0 && (
                        <div className="text-center text-gray-500 py-10 italic">No tests found matching your criteria.</div>
                    )}
                </div>
            </div>
            <PageNavigation onBack={() => setCurrentPage(Page.PatientInfo)} onNext={() => setCurrentPage(Page.TestDetails)} />
        </div>
    );
};

export default TestSelectionPage;
