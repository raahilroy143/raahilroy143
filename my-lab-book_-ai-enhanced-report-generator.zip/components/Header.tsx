
import React from 'react';

const Header: React.FC = () => {
    return (
        <header className="text-center py-8 mb-8 relative shadow-lg rounded-2xl bg-white shadow-blue-500/10">
            <div className="relative inline-block mb-4">
                <div className="absolute top-1 left-1 text-blue-200 text-5xl font-extrabold uppercase tracking-wider -z-10" aria-hidden="true">
                    MY LAB-BOOK
                </div>
                <h1 className="relative text-blue-500 text-5xl font-extrabold uppercase tracking-wider title-main">
                    MY LAB-BOOK
                </h1>
            </div>
            <p className="text-lg italic text-blue-600 tracking-wide">
                Presented by RVK EDITION
            </p>
        </header>
    );
};

export default Header;
