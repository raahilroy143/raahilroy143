
import React, { useState, useCallback } from 'react';
import type { PatientData, TestResult } from '../types';
import { Page } from '../types';
import PageNavigation from './PageNavigation';
import { generatePdf } from '../services/pdfService';
import { saveReport as saveReportToStorage } from '../services/reportService';
import { generateReportSummary } from '../services/geminiService';
import { DownloadIcon, PrintIcon, SaveIcon, SparklesIcon } from './Icons';

interface ReportPreviewPageProps {
    patientData: PatientData;
    selectedTests: TestResult[];
    setCurrentPage: (page: Page) => void;
    showToast: (message: string, type: 'success' | 'error' | 'info') => void;
    refreshReports: () => void;
}

const ReportPreviewPage: React.FC<ReportPreviewPageProps> = ({ patientData, selectedTests, setCurrentPage, showToast, refreshReports }) => {
    const [comment, setComment] = useState('This report contains laboratory test results as requested. Results should be interpreted in the clinical context of the patient. Please consult a healthcare professional for interpretation of results.');
    const [isGenerating, setIsGenerating] = useState(false);

    const handleDownloadPdf = () => {
        generatePdf(patientData, selectedTests, comment);
        showToast('PDF downloaded.', 'success');
    };

    const handlePrint = () => {
        window.print();
    };

    const handleSaveReport = () => {
        try {
            saveReportToStorage(patientData, selectedTests);
            refreshReports();
            showToast('Report saved successfully!', 'success');
        } catch (error) {
            showToast('Failed to save report.', 'error');
            console.error(error);
        }
    };
    
    const handleGenerateSummary = useCallback(async () => {
        setIsGenerating(true);
        showToast('Generating AI summary...', 'info');
        try {
            const summary = await generateReportSummary(patientData, selectedTests);
            setComment(summary);
            showToast('AI summary generated!', 'success');
        } catch (error) {
             let errorMessage = 'Failed to generate summary.';
             if (error instanceof Error) {
                errorMessage = error.message;
             }
             showToast(errorMessage, 'error');
             console.error(error);
        } finally {
            setIsGenerating(false);
        }
    }, [patientData, selectedTests, showToast]);

    const statusClasses: Record<TestResult['status'], string> = {
        normal: 'text-green-700',
        high: 'text-red-700 font-bold',
        low: 'text-yellow-700 font-bold',
        mild: 'text-orange-700 font-bold',
        abnormal: 'text-purple-700 font-bold',
    };

    const ReportContent = () => (
        <div id="report-content" className="bg-white p-8 max-w-4xl mx-auto border border-gray-300 shadow-xl font-serif text-sm">
            <header className="text-center mb-8">
                <h1 className="text-2xl font-bold text-gray-800">MY LAB-BOOK</h1>
                <p className="text-sm italic text-gray-600">Presented by RVK EDITION</p>
            </header>
            <section className="mb-6">
                <h2 className="font-bold border-b border-black pb-1 mb-2">PATIENT INFORMATION</h2>
                <div className="grid grid-cols-2 gap-x-8 gap-y-1">
                    <div><span className="font-semibold">Patient Name:</span> {patientData.name}</div>
                    <div><span className="font-semibold">Date:</span> {patientData.date}</div>
                    <div><span className="font-semibold">Age/Sex:</span> {patientData.age}</div>
                    <div><span className="font-semibold">Daily Case Number:</span> {patientData.caseNumber}</div>
                    <div><span className="font-semibold">Patient ID:</span> {patientData.id}</div>
                    <div><span className="font-semibold">Referred By:</span> {patientData.physician}</div>
                </div>
            </section>
            <section className="mb-6">
                <h2 className="font-bold border-b border-black pb-1 mb-2">RESULTS</h2>
                <table className="w-full border-collapse">
                    <thead>
                        <tr className="bg-gray-100">
                            <th className="border border-gray-400 p-2 text-left font-semibold">Investigation</th>
                            <th className="border border-gray-400 p-2 text-left font-semibold">Result</th>
                            <th className="border border-gray-400 p-2 text-left font-semibold">Reference Value</th>
                            <th className="border border-gray-400 p-2 text-left font-semibold">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        {selectedTests.map(test => (
                            <tr key={test.name}>
                                <td className="border border-gray-400 p-2">{test.name}</td>
                                <td className="border border-gray-400 p-2">{test.value} {test.unit}</td>
                                <td className="border border-gray-400 p-2">{test.range}</td>
                                <td className={`border border-gray-400 p-2 ${statusClasses[test.status]}`}>
                                    {test.status.charAt(0).toUpperCase() + test.status.slice(1)}
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </section>
            <section className="mb-6">
                <h2 className="font-bold border-b border-black pb-1 mb-2">COMMENT</h2>
                <p className="text-justify whitespace-pre-wrap">{comment}</p>
            </section>
            <footer className="mt-20 text-center">
                <div className="text-right">
                    <div className="inline-block text-center">
                        <div className="border-t-2 border-gray-600 w-64 pt-2">
                           Laboratory Director Signature
                        </div>
                    </div>
                </div>
                <p className="mt-8 font-bold">Thanks for Reference</p>
            </footer>
        </div>
    );
    
    return (
        <div className="page active">
            <ReportContent />
            <div className="flex flex-wrap justify-center gap-4 my-8 print:hidden">
                <button onClick={handleGenerateSummary} disabled={isGenerating} className="flex items-center gap-2 bg-gradient-to-r from-purple-500 to-indigo-500 text-white font-bold py-3 px-6 rounded-full shadow-md hover:shadow-lg hover:-translate-y-1 transition-all disabled:opacity-50 disabled:cursor-wait">
                    <SparklesIcon /> {isGenerating ? 'Generating...' : 'Generate AI Summary'}
                </button>
                 <button onClick={handleDownloadPdf} className="flex items-center gap-2 bg-gradient-to-r from-red-500 to-pink-500 text-white font-bold py-3 px-6 rounded-full shadow-md hover:shadow-lg hover:-translate-y-1 transition-all">
                    <DownloadIcon /> Download PDF
                </button>
                <button onClick={handlePrint} className="flex items-center gap-2 bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-bold py-3 px-6 rounded-full shadow-md hover:shadow-lg hover:-translate-y-1 transition-all">
                    <PrintIcon /> Print Report
                </button>
                 <button onClick={handleSaveReport} className="flex items-center gap-2 bg-gradient-to-r from-green-500 to-emerald-400 text-white font-bold py-3 px-6 rounded-full shadow-md hover:shadow-lg hover:-translate-y-1 transition-all">
                    <SaveIcon /> Save Report
                </button>
            </div>
            <div className="print:hidden">
              <PageNavigation onBack={() => setCurrentPage(Page.TestDetails)} />
            </div>
        </div>
    );
};

export default ReportPreviewPage;
