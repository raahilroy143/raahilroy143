
import React, { useState, useEffect } from 'react';
import type { PatientData, Report } from '../types';
import { Page } from '../types';
import PageNavigation from './PageNavigation';
import { SaveIcon, UserPlusIcon, TrashIcon, LoadIcon } from './Icons';
import { deleteReport as deleteReportFromStorage } from '../services/reportService';

interface PatientInfoPageProps {
    onSave: (data: PatientData) => void;
    setCurrentPage: (page: Page) => void;
    reports: Report[];
    loadReport: (report: Report) => void;
    deleteReportCallback: () => void;
    showToast: (message: string, type: 'success' | 'error' | 'info') => void;
    initialData: PatientData | null;
    startNewReport: () => void;
}

const PatientInfoPage: React.FC<PatientInfoPageProps> = ({ onSave, setCurrentPage, reports, loadReport, deleteReportCallback, showToast, initialData, startNewReport }) => {
    const [formData, setFormData] = useState<PatientData>(initialData || {
        name: '',
        age: '',
        id: '',
        date: new Date().toISOString().split('T')[0],
        caseNumber: '',
        physician: '',
    });
    const [errors, setErrors] = useState<Partial<Record<keyof PatientData, string>>>({});

    useEffect(() => {
        if (initialData) {
            setFormData(initialData);
        } else {
             setFormData({
                name: '', age: '', id: '',
                date: new Date().toISOString().split('T')[0],
                caseNumber: '', physician: '',
            });
        }
    }, [initialData]);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { id, value } = e.target;
        setFormData(prev => ({ ...prev, [id]: value }));
        if (value) {
            setErrors(prev => ({ ...prev, [id]: undefined }));
        }
    };

    const validate = (): boolean => {
        const newErrors: Partial<Record<keyof PatientData, string>> = {};
        if (!formData.name) newErrors.name = "Full name is required";
        if (!formData.age) newErrors.age = "Age and sex are required";
        if (!formData.id) newErrors.id = "Patient ID is required";
        if (!formData.date) newErrors.date = "Date is required";
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSave = () => {
        if (validate()) {
            onSave(formData);
        } else {
            showToast('Please fill in all required fields.', 'error');
        }
    };
    
    const handleDeleteReport = (reportId: string) => {
        if(window.confirm('Are you sure you want to delete this report?')) {
            deleteReportFromStorage(reportId);
            deleteReportCallback();
            showToast('Report deleted.', 'info');
        }
    }

    const FormField: React.FC<{ id: keyof PatientData; label: string; placeholder: string; required?: boolean; type?: string }> = ({ id, label, placeholder, required = false, type = 'text' }) => (
        <div>
            <label htmlFor={id} className="block mb-2 font-semibold text-blue-700">
                {label} {required && <span className="text-red-500">*</span>}
            </label>
            <input
                type={type}
                id={id}
                value={formData[id]}
                onChange={handleChange}
                placeholder={placeholder}
                className={`w-full p-3 border-2 rounded-lg font-sans bg-gray-50 transition-all duration-300 ${errors[id] ? 'border-red-400' : 'border-blue-100 focus:border-blue-500'} focus:outline-none focus:ring-2 focus:ring-blue-300`}
            />
            {errors[id] && <div className="text-red-500 text-sm mt-1">{errors[id]}</div>}
        </div>
    );

    return (
        <div className="page active">
            <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-blue-100 mb-8">
                <h2 className="text-center text-blue-700 mb-6 text-2xl font-bold">Patient Information</h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <FormField id="name" label="Full Name" placeholder="Enter patient's full name" required />
                    <FormField id="age" label="Age / Sex" placeholder="e.g., 60 years / Female" required />
                    <FormField id="id" label="Patient ID" placeholder="Enter patient ID" required />
                    <FormField id="date" label="Date" placeholder="" type="date" required />
                    <FormField id="caseNumber" label="Daily Case Number" placeholder="Enter case number" />
                    <FormField id="physician" label="Referred By" placeholder="Enter referring physician" />
                </div>
                <button
                    onClick={handleSave}
                    className="w-full bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-bold py-3 px-6 rounded-full flex items-center justify-center gap-2 shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300"
                >
                    <SaveIcon /> Save Patient Information
                </button>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-blue-100 mb-8">
                <div className="flex justify-between items-center mb-6">
                    <h2 className="text-blue-700 text-2xl font-bold">Saved Reports</h2>
                    <button onClick={startNewReport} className="flex items-center gap-2 text-sm font-semibold bg-green-100 text-green-700 px-4 py-2 rounded-full hover:bg-green-200 transition-colors">
                        <UserPlusIcon />
                        New Report
                    </button>
                </div>
                <div className="overflow-x-auto">
                    {reports.length > 0 ? (
                        <table className="w-full text-left">
                            <thead className="bg-blue-50">
                                <tr>
                                    <th className="p-4 font-semibold text-blue-800 rounded-l-lg">Patient Name</th>
                                    <th className="p-4 font-semibold text-blue-800">ID</th>
                                    <th className="p-4 font-semibold text-blue-800">Date</th>
                                    <th className="p-4 font-semibold text-blue-800">Tests</th>
                                    <th className="p-4 font-semibold text-blue-800 rounded-r-lg">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {reports.map(report => (
                                    <tr key={report.id} className="border-b border-blue-100 hover:bg-blue-50/50">
                                        <td className="p-4">{report.patientData.name}</td>
                                        <td className="p-4">{report.patientData.id}</td>
                                        <td className="p-4">{report.patientData.date}</td>
                                        <td className="p-4">{report.tests.length}</td>
                                        <td className="p-4 flex gap-2">
                                            <button onClick={() => loadReport(report)} className="p-2 text-green-600 bg-green-100 rounded-full hover:bg-green-200 transition-colors" title="Load Report"><LoadIcon /></button>
                                            <button onClick={() => handleDeleteReport(report.id)} className="p-2 text-red-600 bg-red-100 rounded-full hover:bg-red-200 transition-colors" title="Delete Report"><TrashIcon /></button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    ) : (
                        <div className="text-center text-gray-500 py-10 italic">No saved reports found. Create your first report!</div>
                    )}
                </div>
            </div>

            <PageNavigation onNext={formData.id ? () => setCurrentPage(Page.TestSelection) : handleSave} />
        </div>
    );
};

export default PatientInfoPage;
