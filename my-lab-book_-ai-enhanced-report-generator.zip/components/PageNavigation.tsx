
import React from 'react';
import { ArrowLeftIcon, ArrowRightIcon } from './Icons';

interface PageNavigationProps {
    onBack?: () => void;
    onNext?: () => void;
    backLabel?: string;
    nextLabel?: string;
}

const NavButton: React.FC<{ onClick?: () => void; children: React.ReactNode; }> = ({ onClick, children }) => (
    <button
        onClick={onClick}
        className="bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-semibold py-3 px-6 rounded-full flex items-center gap-2 shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300 ease-in-out disabled:opacity-50 disabled:cursor-not-allowed"
        disabled={!onClick}
    >
        {children}
    </button>
);

const PageNavigation: React.FC<PageNavigationProps> = ({ onBack, onNext, backLabel = 'Previous', nextLabel = 'Next' }) => {
    return (
        <div className="flex justify-between mt-8">
            <div>
                {onBack && (
                    <NavButton onClick={onBack}>
                        <ArrowLeftIcon />
                        {backLabel}
                    </NavButton>
                )}
            </div>
            <div>
                {onNext && (
                    <NavButton onClick={onNext}>
                        {nextLabel}
                        <ArrowRightIcon />
                    </NavButton>
                )}
            </div>
        </div>
    );
};

export default PageNavigation;
