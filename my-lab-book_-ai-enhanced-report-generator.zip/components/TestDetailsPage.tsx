
import React, { useState, useEffect, useMemo } from 'react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import type { PatientData, TestDefinition, TestResult } from '../types';
import { Page } from '../types';
import PageNavigation from './PageNavigation';
import { SaveIcon, PlusIcon, EditIcon, TrashIcon } from './Icons';
import { TEST_CATEGORIES } from '../constants';

interface TestDetailsPageProps {
    testDefinition: TestDefinition | null;
    patientData: PatientData | null;
    onSaveTest: (testResult: TestResult) => void;
    selectedTests: TestResult[];
    onDeleteTest: (testNameToDelete: string) => void;
    onEditTest: (test: TestDefinition) => void;
    setCurrentPage: (page: Page) => void;
}

const findTestDefinitionByName = (name: string): TestDefinition | undefined => {
    for (const category of TEST_CATEGORIES) {
        for (const test of category.tests) {
            if (test.name === name) {
                return test;
            }
            if (test.subTests) {
                const subtest = test.subTests.find(st => st.name === name);
                if (subtest) return subtest;
            }
        }
    }
    return undefined;
};

const determineStatus = (valueStr: string, rangeStr: string): TestResult['status'] => {
    const value = parseFloat(valueStr);
    if (isNaN(value)) {
        if (rangeStr.toLowerCase().includes('negative') && valueStr.toLowerCase().includes('positive')) return 'abnormal';
        if (rangeStr.toLowerCase().includes('non reactive') && valueStr.toLowerCase().includes('reactive')) return 'abnormal';
        return 'normal';
    }

    const rangeParts = rangeStr.replace(/,/g, '').match(/-?\d+(\.\d+)?/g);
    if (!rangeParts || rangeParts.length < 1) return 'normal';
    
    if (rangeParts.length === 1) {
        if (rangeStr.includes('>')) return value > parseFloat(rangeParts[0]) ? 'normal' : 'low';
        if (rangeStr.includes('<')) return value < parseFloat(rangeParts[0]) ? 'normal' : 'high';
    }

    if (rangeParts.length === 2) {
        const [min, max] = rangeParts.map(parseFloat);
        if (value < min) return 'low';
        if (value > max) return 'high';
    }
    
    return 'normal';
};

const TestDetailsPage: React.FC<TestDetailsPageProps> = ({ testDefinition, patientData, onSaveTest, selectedTests, onDeleteTest, onEditTest, setCurrentPage }) => {
    const [testResult, setTestResult] = useState<TestResult | null>(null);
    
    useEffect(() => {
        if (testDefinition) {
            const existingTest = selectedTests.find(t => t.name === testDefinition.name);

            const gender = patientData?.age.toLowerCase().includes('female') ? 'female' : 'male';
            const range = typeof testDefinition.range === 'object' 
                ? testDefinition.range[gender] || testDefinition.defaultRange || 'N/A'
                : testDefinition.range;
            
            const initialValue = existingTest?.value ?? testDefinition.defaultValue ?? '';
            const initialStatus = determineStatus(initialValue, range);
            const initialInterpretation = testDefinition.interpretation[initialStatus] || testDefinition.interpretation.normal || '';

            setTestResult({
                name: testDefinition.name,
                value: initialValue,
                unit: testDefinition.unit,
                range: range,
                status: initialStatus,
                interpretation: initialInterpretation,
                sampleType: testDefinition.sampleType,
            });
        } else {
            setTestResult(null);
        }
    }, [testDefinition, patientData, selectedTests]);

    const handleValueChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!testResult) return;
        const newValue = e.target.value;
        const newStatus = determineStatus(newValue, testResult.range);
        const newInterpretation = testDefinition?.interpretation[newStatus] || testDefinition?.interpretation.normal || testResult.interpretation;
        setTestResult({ ...testResult, value: newValue, status: newStatus, interpretation: newInterpretation });
    };

    const handleSave = () => {
        if (testResult && testResult.value !== '') {
            onSaveTest(testResult);
        }
    };
    
    const chartData = useMemo(() => {
        return selectedTests.filter(t => !isNaN(parseFloat(t.value)));
    }, [selectedTests]);


    const statusClasses: Record<TestResult['status'], string> = {
        normal: 'bg-green-100 text-green-800 border-green-300',
        high: 'bg-red-100 text-red-800 border-red-300',
        low: 'bg-yellow-100 text-yellow-800 border-yellow-300',
        mild: 'bg-orange-100 text-orange-800 border-orange-300',
        abnormal: 'bg-purple-100 text-purple-800 border-purple-300',
    };

    return (
        <div className="page active">
            <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-blue-100 mb-8">
                <h2 className="text-center text-blue-700 mb-6 text-2xl font-bold">Test Details</h2>
                {testResult ? (
                    <>
                        <div className="bg-blue-50 p-4 rounded-lg mb-6 border border-blue-200">
                            <h3 className="text-blue-900 font-bold text-lg">{testResult.name}</h3>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                            <div className="p-4 bg-blue-50 rounded-lg text-center">
                                <label className="font-semibold text-blue-800 block mb-2">Test Value</label>
                                <input 
                                    type="text"
                                    value={testResult.value}
                                    onChange={handleValueChange}
                                    className="w-full p-2 text-center text-2xl font-bold bg-white rounded-md border-2 border-blue-200 focus:outline-none focus:border-blue-500"
                                />
                                <div className="text-gray-500 mt-1">{testResult.unit}</div>
                            </div>
                            <div className="p-4 bg-blue-50 rounded-lg text-center">
                                <label className="font-semibold text-blue-800 block mb-2">Normal Range</label>
                                <div className="p-2 text-2xl font-bold">{testResult.range}</div>
                                <div className="text-gray-500 mt-1">Reference Range</div>
                            </div>
                            <div className="p-4 bg-blue-50 rounded-lg text-center">
                                <label className="font-semibold text-blue-800 block mb-2">Status</label>
                                <div className={`inline-block px-4 py-1 rounded-full font-semibold border ${statusClasses[testResult.status]}`}>
                                    {testResult.status.charAt(0).toUpperCase() + testResult.status.slice(1)}
                                </div>
                            </div>
                        </div>
                        <button onClick={handleSave} className="w-full bg-gradient-to-r from-blue-500 to-cyan-400 text-white font-bold py-3 px-6 rounded-full flex items-center justify-center gap-2 shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300">
                            <SaveIcon /> Save Test Details
                        </button>
                    </>
                ) : (
                    <div className="text-center text-gray-500 py-10 italic">Select a test from the previous page to enter details.</div>
                )}
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-blue-100">
                <h3 className="text-center text-blue-700 mb-6 text-2xl font-bold">Selected Tests</h3>
                {selectedTests.length > 0 ? (
                    <div className="overflow-x-auto mb-6">
                        <table className="w-full text-left">
                           <thead className="bg-blue-50">
                                <tr>
                                    <th className="p-3 font-semibold text-blue-800">Test Name</th>
                                    <th className="p-3 font-semibold text-blue-800">Value</th>
                                    <th className="p-3 font-semibold text-blue-800">Range</th>
                                    <th className="p-3 font-semibold text-blue-800">Status</th>
                                    <th className="p-3 font-semibold text-blue-800">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                {selectedTests.map(test => (
                                    <tr key={test.name} className="border-b border-blue-100 hover:bg-blue-50/50">
                                        <td className="p-3 font-medium">{test.name}</td>
                                        <td className="p-3">{test.value} {test.unit}</td>
                                        <td className="p-3">{test.range}</td>
                                        <td className="p-3">
                                            <span className={`px-3 py-1 text-sm rounded-full font-semibold border ${statusClasses[test.status]}`}>
                                                {test.status.charAt(0).toUpperCase() + test.status.slice(1)}
                                            </span>
                                        </td>
                                        <td className="p-3 flex gap-2">
                                            <button onClick={() => {
                                                const def = findTestDefinitionByName(test.name);
                                                if (def) onEditTest(def);
                                            }} className="p-2 text-blue-600 bg-blue-100 rounded-full hover:bg-blue-200"><EditIcon /></button>
                                            <button onClick={() => onDeleteTest(test.name)} className="p-2 text-red-600 bg-red-100 rounded-full hover:bg-red-200"><TrashIcon /></button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                ) : (
                    <div className="text-center text-gray-500 py-6 italic">No tests added yet.</div>
                )}

                {chartData.length > 0 && (
                    <div className="mt-8">
                        <h3 className="text-center text-blue-700 mb-4 text-xl font-bold">Results Visualization</h3>
                        <div style={{ width: '100%', height: 300 }}>
                            <ResponsiveContainer>
                                <BarChart data={chartData} layout="vertical" margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                                    <XAxis type="number" />
                                    <YAxis dataKey="name" type="category" width={150} tick={{ fontSize: 12 }} />
                                    <Tooltip />
                                    <Bar dataKey="value" name="Test Value" >
                                       {chartData.map((entry, index) => (
                                          <Cell key={`cell-${index}`} fill={statusClasses[entry.status].split(' ')[0].replace('bg-', 'bg-').replace('-100', '-400')} />
                                       ))}
                                    </Bar>
                                </BarChart>
                            </ResponsiveContainer>
                        </div>
                    </div>
                )}
                
                <div className="text-center mt-6">
                    <button onClick={() => setCurrentPage(Page.TestSelection)} className="bg-gradient-to-r from-green-500 to-emerald-400 text-white font-bold py-3 px-6 rounded-full flex items-center justify-center gap-2 shadow-md hover:shadow-lg hover:-translate-y-1 transition-all duration-300 mx-auto">
                        <PlusIcon /> Add Another Test
                    </button>
                </div>
            </div>

            <PageNavigation onBack={() => setCurrentPage(Page.TestSelection)} onNext={selectedTests.length > 0 ? () => setCurrentPage(Page.ReportPreview) : undefined} />
        </div>
    );
};

export default TestDetailsPage;
