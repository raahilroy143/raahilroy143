
import type { TestCategory } from './types';

export const TEST_CATEGORIES: TestCategory[] = [
    {
        id: 'hematology',
        name: 'Hematology',
        tests: [
            {
                name: 'Complete Blood Count (CBC)',
                description: 'A panel of tests evaluating the cells that circulate in the blood.',
                category: 'hematology',
                sampleType: 'Blood',
                unit: '',
                range: '',
                interpretation: {},
                subTests: [
                    { name: 'Hemoglobin (Hb)', description: 'Measures oxygen-carrying protein.', category: 'hematology', sampleType: 'Blood', unit: 'g/dL', range: { male: '13.5-17.5', female: '12.0-15.5', child: '11.0-16.0' }, defaultRange: '12.0-15.5', defaultValue: '13.8', interpretation: { high: 'May indicate polycythemia or dehydration.', low: 'May indicate anemia or blood loss.', normal: 'Normal oxygen-carrying capacity.' } },
                    { name: 'Red Blood Cell Count (RBC)', description: 'Count of red blood cells.', category: 'hematology', sampleType: 'Blood', unit: 'million/μL', range: { male: '4.5-5.9', female: '4.0-5.2', child: '3.8-5.5' }, defaultRange: '4.0-5.2', defaultValue: '4.7', interpretation: { high: 'May indicate polycythemia.', low: 'May indicate anemia.', normal: 'Normal red blood cell production.' } },
                    { name: 'White Blood Cell Count (WBC)', description: 'Count of white blood cells.', category: 'hematology', sampleType: 'Blood', unit: 'K/μL', range: '4.5-11.0', defaultValue: '7.5', interpretation: { high: 'May indicate infection or inflammation.', low: 'May indicate immunosuppression.', normal: 'Normal immune function.' } },
                    { name: 'Platelet Count (PLT)', description: 'Count of platelets.', category: 'hematology', sampleType: 'Blood', unit: 'K/μL', range: '150-450', defaultValue: '250', interpretation: { high: 'May indicate risk of clotting.', low: 'May indicate risk of bleeding.', normal: 'Normal clotting potential.' } },
                    { name: 'Hematocrit (HCT)', description: 'Proportion of red blood cells.', category: 'hematology', sampleType: 'Blood', unit: '%', range: { male: '41-53', female: '36-46', child: '33-43' }, defaultRange: '36-46', defaultValue: '42', interpretation: { high: 'May indicate dehydration.', low: 'May indicate anemia.', normal: 'Normal blood volume concentration.' } },
                    { name: 'Mean Corpuscular Volume (MCV)', description: 'Average size of red blood cells.', category: 'hematology', sampleType: 'Blood', unit: 'fL', range: '80-100', defaultValue: '88', interpretation: { high: 'Macrocytic cells, may suggest B12/folate deficiency.', low: 'Microcytic cells, may suggest iron deficiency.', normal: 'Normal size of red blood cells.' } },
                    { name: 'Mean Corpuscular Hemoglobin (MCH)', description: 'Amount of hemoglobin per red blood cell.', category: 'hematology', sampleType: 'Blood', unit: 'pg', range: '27-33', defaultValue: '30', interpretation: { low: 'Hypochromic, may suggest iron deficiency.', normal: 'Normal amount of hemoglobin in cells.' } },
                    { name: 'MCHC', description: 'Concentration of hemoglobin in a red blood cell.', category: 'hematology', sampleType: 'Blood', unit: 'g/dL', range: '32-36', defaultValue: '34', interpretation: { low: 'Hypochromic, may suggest iron deficiency.', normal: 'Normal concentration of hemoglobin.' } },
                    { name: 'Red Cell Distribution Width (RDW)', description: 'Variation in red blood cell size.', category: 'hematology', sampleType: 'Blood', unit: '%', range: '11.5-14.5', defaultValue: '13.0', interpretation: { high: 'Anisocytosis, may suggest deficiencies.', normal: 'Uniform size of red blood cells.' } },
                ]
            },
            {
                name: 'Differential Leukocyte Count (DLC)',
                description: 'Percentages of different types of white blood cells.',
                category: 'hematology',
                sampleType: 'Blood',
                unit: '',
                range: '',
                interpretation: {},
                subTests: [
                    { name: 'Neutrophils', description: 'Type of white blood cell.', category: 'hematology', sampleType: 'Blood', unit: '%', range: '40-70', defaultValue: '55', interpretation: { high: 'Neutrophilia, suggests bacterial infection.', low: 'Neutropenia, increased risk of infection.', normal: 'Normal.' } },
                    { name: 'Lymphocytes', description: 'Type of white blood cell.', category: 'hematology', sampleType: 'Blood', unit: '%', range: '20-40', defaultValue: '30', interpretation: { high: 'Lymphocytosis, suggests viral infection.', low: 'Lymphopenia, may indicate immune issues.', normal: 'Normal.' } },
                    { name: 'Monocytes', description: 'Type of white blood cell.', category: 'hematology', sampleType: 'Blood', unit: '%', range: '2-10', defaultValue: '6', interpretation: { high: 'Monocytosis, suggests chronic inflammation.', normal: 'Normal.' } },
                    { name: 'Eosinophils', description: 'Type of white blood cell.', category: 'hematology', sampleType: 'Blood', unit: '%', range: '1-6', defaultValue: '3', interpretation: { high: 'Eosinophilia, suggests allergic reactions or parasitic infection.', normal: 'Normal.' } },
                    { name: 'Basophils', description: 'Type of white blood cell.', category: 'hematology', sampleType: 'Blood', unit: '%', range: '0-2', defaultValue: '1', interpretation: { high: 'Basophilia, seen in some allergic reactions.', normal: 'Normal.' } },
                ]
            },
            { name: 'Erythrocyte Sedimentation Rate (ESR)', description: 'Measures inflammation in the body.', category: 'hematology', sampleType: 'Blood', unit: 'mm/hr', range: { male: '0-15', female: '0-20', child: '0-10' }, defaultRange: '0-20', defaultValue: '12', interpretation: { high: 'Indicates inflammation, infection, or other conditions.', normal: 'No significant inflammation detected.' } },
            { name: 'Coagulation Profile', description: 'Evaluates blood clotting ability.', category: 'hematology', sampleType: 'Blood', unit: '', range: 'Normal', defaultValue: 'Normal', interpretation: { abnormal: 'May indicate a bleeding or clotting disorder.' } },
        ]
    },
    {
        id: 'biochemistry',
        name: 'Biochemistry',
        tests: [
            { name: 'Glucose (Fasting)', description: 'Measures blood sugar levels after fasting.', category: 'biochemistry', sampleType: 'Blood', unit: 'mg/dL', range: '70-99', defaultValue: '85', interpretation: { high: 'Hyperglycemia, may indicate diabetes.', low: 'Hypoglycemia.', normal: 'Normal blood sugar control.' } },
            { name: 'HbA1c (Glycated Hemoglobin)', description: 'Average blood sugar over 2-3 months.', category: 'biochemistry', sampleType: 'Blood', unit: '%', range: '4.0-5.6', defaultValue: '5.2', interpretation: { high: 'Indicates poor long-term glucose control, risk for diabetes.', normal: 'Good long-term glucose control.' } },
            { name: 'Lipid Profile', description: 'Measures cholesterol and triglycerides.', category: 'biochemistry', sampleType: 'Blood', unit: '', range: 'See components', interpretation: {}, subTests: [
                    { name: 'Total Cholesterol', description: 'Total amount of cholesterol in blood.', category: 'biochemistry', sampleType: 'Blood', unit: 'mg/dL', range: '<200', defaultValue: '180', interpretation: { high: 'Increased cardiovascular risk.' } },
                    { name: 'Triglycerides', description: 'Type of fat in blood.', category: 'biochemistry', sampleType: 'Blood', unit: 'mg/dL', range: '<150', defaultValue: '120', interpretation: { high: 'Increased cardiovascular risk.' } },
                    { name: 'HDL Cholesterol', description: '"Good" cholesterol.', category: 'biochemistry', sampleType: 'Blood', unit: 'mg/dL', range: '>40', defaultValue: '50', interpretation: { low: 'Increased cardiovascular risk.' } },
                    { name: 'LDL Cholesterol', description: '"Bad" cholesterol.', category: 'biochemistry', sampleType: 'Blood', unit: 'mg/dL', range: '<100', defaultValue: '90', interpretation: { high: 'Increased cardiovascular risk.' } },
                ] 
            },
            { name: 'Liver Function Tests (LFTs)', description: 'Assesses liver health.', category: 'biochemistry', sampleType: 'Blood', unit: '', range: 'See components', interpretation: {}, subTests: [
                { name: 'ALT (Alanine Aminotransferase)', description: 'Enzyme found in the liver.', category: 'biochemistry', sampleType: 'Blood', unit: 'U/L', range: '7-56', defaultValue: '30', interpretation: { high: 'May indicate liver damage.' } },
                { name: 'AST (Aspartate Aminotransferase)', description: 'Enzyme found in liver and other organs.', category: 'biochemistry', sampleType: 'Blood', unit: 'U/L', range: '10-40', defaultValue: '25', interpretation: { high: 'May indicate liver damage.' } },
                { name: 'Alkaline Phosphatase (ALP)', description: 'Enzyme related to bile ducts.', category: 'biochemistry', sampleType: 'Blood', unit: 'U/L', range: '44-147', defaultValue: '80', interpretation: { high: 'May indicate liver or bone issues.' } },
                { name: 'Bilirubin (Total)', description: 'Product of red blood cell breakdown.', category: 'biochemistry', sampleType: 'Blood', unit: 'mg/dL', range: '0.1-1.2', defaultValue: '0.6', interpretation: { high: 'Jaundice, may indicate liver or bile duct issues.' } },
            ]},
            { name: 'Kidney Function Tests', description: 'Assesses kidney health.', category: 'biochemistry', sampleType: 'Blood', unit: '', range: 'See components', interpretation: {}, subTests: [
                { name: 'Creatinine', description: 'Waste product filtered by kidneys.', category: 'biochemistry', sampleType: 'Blood', unit: 'mg/dL', range: '0.6-1.3', defaultValue: '1.0', interpretation: { high: 'May indicate impaired kidney function.' } },
                { name: 'Blood Urea Nitrogen (BUN)', description: 'Waste product from protein breakdown.', category: 'biochemistry', sampleType: 'Blood', unit: 'mg/dL', range: '7-20', defaultValue: '15', interpretation: { high: 'May indicate kidney or liver issues.' } },
                { name: 'eGFR', description: 'Estimated Glomerular Filtration Rate.', category: 'biochemistry', sampleType: 'Blood', unit: 'mL/min/1.73m²', range: '>60', defaultValue: '90', interpretation: { low: 'May indicate chronic kidney disease.' } },
            ]},
            { name: 'Uric Acid', description: 'Measures uric acid levels in the blood.', category: 'biochemistry', sampleType: 'Blood', unit: 'mg/dL', range: { male: '3.4-7.0', female: '2.4-6.0', child: '2.0-5.5' }, defaultRange: '2.4-6.0', defaultValue: '5.0', interpretation: { high: 'Hyperuricemia, risk for gout.', normal: 'Normal level.' } },
        ]
    },
    {
        id: 'urine_analysis',
        name: 'Urine Analysis',
        tests: [
            {
                name: 'Urinalysis (Dipstick)',
                description: 'A panel of tests on a urine sample.',
                category: 'urine_analysis',
                sampleType: 'Urine',
                unit: '',
                range: '',
                interpretation: {},
                subTests: [
                    { name: 'Color', description: 'Visual color of urine.', category: 'urine_analysis', sampleType: 'Urine', unit: '', range: 'Yellow', defaultValue: 'Yellow', interpretation: { abnormal: 'Abnormal color can be due to diet, medication, or disease.' } },
                    { name: 'Clarity', description: 'Clarity of urine.', category: 'urine_analysis', sampleType: 'Urine', unit: '', range: 'Clear', defaultValue: 'Clear', interpretation: { abnormal: 'Cloudy urine may indicate infection.' } },
                    { name: 'pH', description: 'Acidity of urine.', category: 'urine_analysis', sampleType: 'Urine', unit: '', range: '4.5-8.0', defaultValue: '6.0', interpretation: { abnormal: 'May indicate kidney or urinary tract disorders.' } },
                    { name: 'Specific Gravity', description: 'Concentration of urine.', category: 'urine_analysis', sampleType: 'Urine', unit: '', range: '1.005-1.030', defaultValue: '1.015', interpretation: { high: 'Dehydration.', low: 'Over-hydration or kidney issues.' } },
                    { name: 'Protein', description: 'Presence of protein.', category: 'urine_analysis', sampleType: 'Urine', unit: '', range: 'Negative', defaultValue: 'Negative', interpretation: { abnormal: 'Proteinuria, may indicate kidney disease.' } },
                    { name: 'Glucose', description: 'Presence of glucose.', category: 'urine_analysis', sampleType: 'Urine', unit: '', range: 'Negative', defaultValue: 'Negative', interpretation: { abnormal: 'Glucosuria, may indicate diabetes.' } },
                    { name: 'Ketones', description: 'Presence of ketones.', category: 'urine_analysis', sampleType: 'Urine', unit: '', range: 'Negative', defaultValue: 'Negative', interpretation: { abnormal: 'Ketonuria, may indicate diabetic ketoacidosis or starvation.' } },
                    { name: 'Nitrites', description: 'Indicator of bacteria.', category: 'urine_analysis', sampleType: 'Urine', unit: '', range: 'Negative', defaultValue: 'Negative', interpretation: { abnormal: 'Suggests urinary tract infection (UTI).' } },
                    { name: 'Leukocyte Esterase', description: 'Indicator of white blood cells.', category: 'urine_analysis', sampleType: 'Urine', unit: '', range: 'Negative', defaultValue: 'Negative', interpretation: { abnormal: 'Suggests urinary tract infection (UTI).' } },
                ]
            },
            {
                name: 'Urine Microscopy',
                description: 'Microscopic examination of urine sediment.',
                category: 'urine_analysis',
                sampleType: 'Urine',
                unit: '',
                range: '',
                interpretation: {},
                subTests: [
                    { name: 'Red Blood Cells (RBC)', description: 'RBCs in urine.', category: 'urine_analysis', sampleType: 'Urine', unit: '/HPF', range: '0-2', defaultValue: '1', interpretation: { abnormal: 'Hematuria, can indicate infection, stones, or other issues.' } },
                    { name: 'White Blood Cells (WBC)', description: 'WBCs in urine.', category: 'urine_analysis', sampleType: 'Urine', unit: '/HPF', range: '0-5', defaultValue: '2', interpretation: { abnormal: 'Pyuria, indicates inflammation or infection (UTI).' } },
                    { name: 'Epithelial Cells', description: 'Cells from urinary tract lining.', category: 'urine_analysis', sampleType: 'Urine', unit: '/HPF', range: 'Few', defaultValue: 'Few', interpretation: { abnormal: 'Large numbers may indicate contamination or inflammation.' } },
                    { name: 'Casts', description: 'Cylindrical structures from kidneys.', category: 'urine_analysis', sampleType: 'Urine', unit: '', range: 'None', defaultValue: 'None', interpretation: { abnormal: 'Presence of certain casts can indicate kidney disease.' } },
                ]
            }
        ]
    },
    {
        id: 'stool_analysis',
        name: 'Stool Analysis',
        tests: [
            { name: 'Stool Occult Blood (FOBT)', description: 'Checks for hidden blood in stool.', category: 'stool_analysis', sampleType: 'Stool', unit: '', range: 'Negative', defaultValue: 'Negative', interpretation: { abnormal: 'Positive result indicates bleeding in the digestive tract, requires further investigation.' } },
            { name: 'Stool Examination (Ova & Parasites)', description: 'Looks for parasites and their eggs.', category: 'stool_analysis', sampleType: 'Stool', unit: '', range: 'Not Seen', defaultValue: 'Not Seen', interpretation: { abnormal: 'Indicates a parasitic infection.' } },
            { name: 'Stool Culture', description: 'Checks for harmful bacteria in the gut.', category: 'stool_analysis', sampleType: 'Stool', unit: '', range: 'No pathogenic organisms grown', defaultValue: 'No pathogenic organisms grown', interpretation: { abnormal: 'Indicates a bacterial infection in the digestive tract.' } },
        ]
    },
];
