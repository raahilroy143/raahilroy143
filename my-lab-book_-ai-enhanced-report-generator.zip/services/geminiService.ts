
import { GoogleGenAI } from "@google/genai";
import type { PatientData, TestResult } from "../types";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.warn("API_KEY environment variable not set. AI features will be disabled.");
}

const ai = new GoogleGenAI({ apiKey: API_KEY! });

export async function generateReportSummary(patientData: PatientData, testResults: TestResult[]): Promise<string> {
    if (!API_KEY) {
        throw new Error("Gemini API key is not configured. Please set the API_KEY environment variable.");
    }
    
    const model = 'gemini-2.5-flash';

    const systemInstruction = `You are a helpful medical assistant. Analyze the following lab report and provide a simple, easy-to-understand summary for the patient in about 150-200 words. 
- Do not provide a diagnosis or medical advice.
- Start with a general overview.
- For any results outside the normal range, briefly explain what the test measures and what the result might suggest in simple terms (e.g., "high glucose can be related to blood sugar levels").
- Conclude by strongly recommending the patient discuss these results with their doctor for a formal interpretation and diagnosis.
- Format the output with clear paragraphs. Do not use markdown like lists or bolding.`;

    const testResultsString = testResults
        .map(t => `- ${t.name}: ${t.value} ${t.unit} (Normal Range: ${t.range}, Status: ${t.status})`)
        .join('\n');

    const prompt = `
Patient Information:
- Name: ${patientData.name}
- Age/Sex: ${patientData.age}

Test Results:
${testResultsString}

Please provide a summary based on these results.
`;

    try {
        const response = await ai.models.generateContent({
            model: model,
            contents: prompt,
            config: {
                systemInstruction: systemInstruction,
            },
        });
        
        return response.text;

    } catch (error) {
        console.error("Error calling Gemini API:", error);
        throw new Error("There was an issue communicating with the AI. Please try again later.");
    }
}
