
import type { PatientData, TestResult, Report } from '../types';

const STORAGE_KEY = 'labReports';

export const loadReports = (): Report[] => {
    try {
        const storedReports = localStorage.getItem(STORAGE_KEY);
        if (storedReports) {
            const reports: Report[] = JSON.parse(storedReports);
            // Sort by creation date, newest first
            return reports.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
        }
    } catch (error) {
        console.error("Failed to load reports from localStorage", error);
    }
    return [];
};

export const saveReport = (patientData: PatientData, tests: TestResult[]): void => {
    const reports = loadReports();
    
    const newReport: Report = {
        id: Date.now().toString(),
        patientData,
        tests,
        createdAt: new Date().toISOString(),
    };

    reports.unshift(newReport); // Add to the beginning

    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
    } catch (error) {
        console.error("Failed to save report to localStorage", error);
        throw new Error("Could not save the report. Storage might be full.");
    }
};

export const deleteReport = (reportId: string): void => {
    let reports = loadReports();
    reports = reports.filter(report => report.id !== reportId);
    
    try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
    } catch (error) {
        console.error("Failed to delete report from localStorage", error);
    }
};
