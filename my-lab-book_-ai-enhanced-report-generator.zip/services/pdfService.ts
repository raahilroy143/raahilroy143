
import { jsPDF } from 'jspdf';
import 'jspdf-autotable';
import type { PatientData, TestResult } from '../types';

export function generatePdf(patientData: PatientData, selectedTests: TestResult[], comment: string) {
    const doc = new jsPDF();
    
    // Header
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(20);
    doc.text('MY LAB-BOOK', doc.internal.pageSize.getWidth() / 2, 20, { align: 'center' });
    doc.setFont('helvetica', 'italic');
    doc.setFontSize(12);
    doc.text('Presented by RVK EDITION', doc.internal.pageSize.getWidth() / 2, 28, { align: 'center' });
    
    // Patient Information
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text('PATIENT INFORMATION', 14, 45);
    doc.setDrawColor(0);
    doc.line(14, 46, doc.internal.pageSize.getWidth() - 14, 46);
    
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    doc.text(`Patient Name: ${patientData.name}`, 14, 55);
    doc.text(`Age/Sex: ${patientData.age}`, 14, 60);
    doc.text(`Patient ID: ${patientData.id}`, 14, 65);
    
    const rightColX = doc.internal.pageSize.getWidth() / 2 + 10;
    doc.text(`Date: ${patientData.date}`, rightColX, 55);
    doc.text(`Daily Case Number: ${patientData.caseNumber}`, rightColX, 60);
    doc.text(`Referred By: ${patientData.physician}`, rightColX, 65);

    // Results Table
    const tableBody = selectedTests.map(test => [
        test.name,
        `${test.value} ${test.unit}`,
        test.range,
        test.status.charAt(0).toUpperCase() + test.status.slice(1),
    ]);
    
    (doc as any).autoTable({
        startY: 75,
        head: [['Investigation', 'Result', 'Reference Value', 'Status']],
        body: tableBody,
        theme: 'grid',
        headStyles: {
            fillColor: [230, 247, 255], // Light blue
            textColor: [23, 78, 117], // Dark blue
            fontStyle: 'bold',
        },
        styles: {
            font: 'helvetica',
            fontSize: 9,
        },
        alternateRowStyles: {
            fillColor: [248, 251, 253]
        },
    });

    // Comment Section
    const finalY = (doc as any).autoTable.previous.finalY;
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(14);
    doc.text('COMMENT', 14, finalY + 15);
    doc.line(14, finalY + 16, doc.internal.pageSize.getWidth() - 14, finalY + 16);
    
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(10);
    const splitComment = doc.splitTextToSize(comment, doc.internal.pageSize.getWidth() - 28);
    doc.text(splitComment, 14, finalY + 22);

    // Footer & Signature
    const footerY = doc.internal.pageSize.getHeight() - 30;
    const signatureX = doc.internal.pageSize.getWidth() - 70;
    doc.line(signatureX, footerY, doc.internal.pageSize.getWidth() - 14, footerY);
    doc.text('Laboratory Director Signature', signatureX - 5, footerY + 5);
    
    doc.setFont('helvetica', 'bold');
    doc.text('Thanks for Reference', doc.internal.pageSize.getWidth() / 2, footerY + 15, { align: 'center' });
    
    const patientNameFile = patientData.name.replace(/\s+/g, '_');
    doc.save(`Lab_Report_${patientNameFile}_${patientData.date.replace(/\//g, '-')}.pdf`);
}
